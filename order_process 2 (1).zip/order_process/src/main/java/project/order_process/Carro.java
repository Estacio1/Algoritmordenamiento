package project.order_process;

public class Carro {

    private String Marca;
    private int Modelo;
    private String Color;
    private int Kilometraje;

    public Carro(String Marca, int Modelo, String Color, int Kilometraje) {
        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Color = Color;
        this.Kilometraje = Kilometraje;
    }

    public String getMarca() {
        return this.Marca;
    }

    public int getModelo() {
        return this.Modelo;
    }

    public String getColor() {
        return this.Color;
    }

    public int getKilometraje() {
        return this.Kilometraje;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public void setModelo(int Modelo) {
        this.Modelo = Modelo;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public void setKilometraje(int Kilometraje) {
        this.Kilometraje = Kilometraje;
    }
}
