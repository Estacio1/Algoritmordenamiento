package project.order_process;

import java.util.Scanner;

public class Order_process {

    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        String label = "Seleccione cual ejercicio desea ejecutar [1-4], 0 para salir";
        int option = 10;

        while (option != 0) {
            System.out.println(label);
            option = lector.nextInt();

            if (option == 1) {
                Thirdone.main();
            }

            if (option == 2) {
                Thirdtwo.main();
            }

            if (option == 3) {
                Thirdthree.main();
            }

            if (option == 4) {
                System.out.println("1 -> Personas, 2 -> Carros");
                int suboption = lector.nextInt();
                if (suboption == 1) {
                    ThirdfourPersona.main();
                } else {
                    ThirdfourCarro.main();
                }
            }
        }

    }
}
