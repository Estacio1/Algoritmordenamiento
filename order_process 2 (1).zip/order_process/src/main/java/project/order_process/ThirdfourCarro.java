package project.order_process;

import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ThirdfourCarro extends JFrame {

    private JTextField marcaField, modeloField, colorField, kilometrajeField;
    private JButton agregarButton, ordenarButton;
    private JComboBox<String> metodoBox;
    private JComboBox<String> ordernarPor;
    private DefaultListModel<Carro> carrosModel;
    private JTable tabla;
    private JScrollPane scroll;
    private Object[][] datos;

    public ThirdfourCarro() {
        setLayout(new FlowLayout());

        JLabel marcaLabel = new JLabel("Marca");
        add(marcaLabel);

        marcaField = new JTextField(10);
        add(marcaField);

        JLabel modeloLabel = new JLabel("Modelo");
        add(modeloLabel);

        modeloField = new JTextField(10);
        add(modeloField);

        JLabel colorLabel = new JLabel("Color");
        add(colorLabel);

        colorField = new JTextField(10);
        add(colorField);

        JLabel kilometrajeLabel = new JLabel("Kilometraje");
        add(kilometrajeLabel);

        kilometrajeField = new JTextField(10);
        add(kilometrajeField);

        agregarButton = new JButton("Agregar");
        add(agregarButton);

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = marcaField.getText();
                int modelo = Integer.parseInt(modeloField.getText());
                String color = colorField.getText();
                int kilometraje = Integer.parseInt(kilometrajeField.getText());
                Carro carro = new Carro(marca, modelo, color, kilometraje);
                carrosModel.addElement(carro);
                marcaField.setText("");
                modeloField.setText("");
                colorField.setText("");
                kilometrajeField.setText("");
                generDataTable(false);
            }
        });

        JLabel metodoLabel = new JLabel("Método");
        add(metodoLabel);

        metodoBox = new JComboBox<>(new String[]{"Burbuja", "Mergesort"});
        add(metodoBox);

        ordernarPor = new JComboBox<>(new String[]{"Modelo", "Kilometraje"});
        add(ordernarPor);

        ordenarButton = new JButton("Ordenar");
        add(ordenarButton);

        ordenarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Carro[] carros = new Carro[carrosModel.getSize()];
                carrosModel.copyInto(carros);
                String option = "modelo";
                if (ordernarPor.getSelectedIndex() != 0) {
                    option = "kilometraje";
                }
                if (metodoBox.getSelectedIndex() == 0) {
                    bubbleSort(carros, option);
                } else {
                    mergeSort(carros, option);
                }
                carrosModel.clear();
                for (Carro carro : carros) {
                    carrosModel.addElement(carro);
                }
                generDataTable(false);
            }
        });

        generDataTable(true);

        setSize(650, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    public static void main() {
        new ThirdfourCarro();
    }

    private void generDataTable(boolean defaultValue) {
        if (carrosModel == null) {
            carrosModel = new DefaultListModel<>();
        }
        if (defaultValue) {
            carrosModel.addElement(new Carro("Mazda", 2012, "rojo", 1000));
            carrosModel.addElement(new Carro("Renault", 2010, "verde", 1200));
            carrosModel.addElement(new Carro("Chevrolet", 2020, "gris", 900));
        }

        Carro[] carros = new Carro[carrosModel.getSize()];
        carrosModel.copyInto(carros);
        String[] columnas = {"Marca", "Modelo", "Color", "Kilometraje"};

        datos = new Object[carros.length][columnas.length];
        for (int i = 0; i < carros.length; i++) {
            datos[i][0] = carros[i].getMarca();
            datos[i][1] = carros[i].getModelo();
            datos[i][2] = carros[i].getColor();
            datos[i][3] = carros[i].getKilometraje();
        }

        DefaultTableModel modelo = new DefaultTableModel(datos, columnas);
        if (tabla == null) {
            tabla = new JTable(modelo);
            scroll = new JScrollPane(tabla);
            add(scroll);
        } else {
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();
            revalidate();
            repaint();
        }
    }

    public void bubbleSort(Carro[] carros, String tipo) {
        int n = carros.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if ("modelo".equals(tipo) && carros[j].getModelo() > carros[j + 1].getModelo()) {
                    Carro temp = carros[j];
                    carros[j] = carros[j + 1];
                    carros[j + 1] = temp;
                } else if ("kilometraje".equals(tipo) && carros[j].getKilometraje() > carros[j + 1].getKilometraje()) {
                    Carro temp = carros[j];
                    carros[j] = carros[j + 1];
                    carros[j + 1] = temp;
                }

            }
        }
    }

    public static void mergeSort(Carro[] array, String option) {
        int n = array.length;
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        Carro[] left = Arrays.copyOfRange(array, 0, mid);
        Carro[] right = Arrays.copyOfRange(array, mid, n);
        mergeSort(left, option);
        mergeSort(right, option);
        merge(left, right, array, option);
    }

    private static void merge(Carro[] left, Carro[] right, Carro[] array, String option) {
        int i = 0;
        int j = 0;
        int k = 0;
        int leftSize = left.length;
        int rightSize = right.length;
        while (i < leftSize && j < rightSize) {
            if ("modelo".equals(option)) {
                if (left[i].getModelo() <= right[j].getModelo()) {
                    array[k++] = left[i++];
                } else {
                    array[k++] = right[j++];
                }
            } else if ("kilometraje".equals(option)) {
                if (left[i].getKilometraje() <= right[j].getKilometraje()) {
                    array[k++] = left[i++];
                } else {
                    array[k++] = right[j++];
                }
            }
        }
        while (i < leftSize) {
            array[k++] = left[i++];
        }
        while (j < rightSize) {
            array[k++] = right[j++];
        }
    }

}
