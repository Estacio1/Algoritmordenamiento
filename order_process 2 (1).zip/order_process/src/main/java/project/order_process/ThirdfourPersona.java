package project.order_process;

import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ThirdfourPersona extends JFrame {

    private JTextField cedulaField, nombreField, edadField;
    private JButton agregarButton, ordenarButton;
    private JComboBox<String> metodoBox;
    private JComboBox<String> ordernarPor;
    private DefaultListModel<Persona> personasModel;
    private JTable tabla;
    private JScrollPane scroll;
    private Object[][] datos;

    public ThirdfourPersona() {
        setLayout(new FlowLayout());

        JLabel cedulaLabel = new JLabel("Cédula");
        add(cedulaLabel);

        cedulaField = new JTextField(10);
        add(cedulaField);

        JLabel nombreLabel = new JLabel("Nombre");
        add(nombreLabel);

        nombreField = new JTextField(10);
        add(nombreField);

        JLabel edadLabel = new JLabel("Edad");
        add(edadLabel);

        edadField = new JTextField(10);
        add(edadField);

        agregarButton = new JButton("Agregar");
        add(agregarButton);

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int cedula = Integer.parseInt(cedulaField.getText());
                String nombre = nombreField.getText();
                int edad = Integer.parseInt(edadField.getText());
                Persona persona = new Persona(cedula, nombre, edad);
                personasModel.addElement(persona);
                cedulaField.setText("");
                nombreField.setText("");
                edadField.setText("");
                generDataTable(false);
            }
        });

        JLabel metodoLabel = new JLabel("Método");
        add(metodoLabel);

        metodoBox = new JComboBox<>(new String[]{"Burbuja", "Mergesort"});
        add(metodoBox);

        ordernarPor = new JComboBox<>(new String[]{"Cédula", "Edad"});
        add(ordernarPor);

        ordenarButton = new JButton("Ordenar");
        add(ordenarButton);

        ordenarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Persona[] personas = new Persona[personasModel.getSize()];
                personasModel.copyInto(personas);
                String option = "cedula";
                if (ordernarPor.getSelectedIndex() != 0) {
                    option = "edad";
                }
                if (metodoBox.getSelectedIndex() == 0) {
                    bubbleSort(personas, option);
                } else {
                    mergeSort(personas, option);
                }
                personasModel.clear();
                for (Persona persona : personas) {
                    personasModel.addElement(persona);
                }
                generDataTable(false);
            }
        });

        generDataTable(true);

        setSize(650, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main() {
        new ThirdfourPersona();
    }

    private void generDataTable(boolean defaultValue) {
        if (personasModel == null) {
            personasModel = new DefaultListModel<>();
        }
        if (defaultValue) {
            personasModel.addElement(new Persona(123, "Juan", 25));
            personasModel.addElement(new Persona(456, "Maria", 30));
            personasModel.addElement(new Persona(789, "Pedro", 35));
            personasModel.addElement(new Persona(888, "Maria", 15));
            personasModel.addElement(new Persona(799, "Jaime", 25));
            personasModel.addElement(new Persona(389, "Sara", 39));
        }

        Persona[] personas = new Persona[personasModel.getSize()];
        personasModel.copyInto(personas);
        String[] columnas = {"Cédula", "Nombre", "Edad"};

        datos = new Object[personas.length][columnas.length];
        for (int i = 0; i < personas.length; i++) {
            datos[i][0] = personas[i].getCedula();
            datos[i][1] = personas[i].getNombre();
            datos[i][2] = personas[i].getEdad();
        }

        DefaultTableModel modelo = new DefaultTableModel(datos, columnas);
        if (tabla == null) {
            tabla = new JTable(modelo);
            scroll = new JScrollPane(tabla);
            add(scroll);
        } else {
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();
            revalidate();
            repaint();
        }
    }

    public void bubbleSort(Persona[] personas, String tipo) {
        int n = personas.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if ("cedula".equals(tipo) && personas[j].getCedula() > personas[j + 1].getCedula()) {
                    Persona temp = personas[j];
                    personas[j] = personas[j + 1];
                    personas[j + 1] = temp;
                } else if ("edad".equals(tipo) && personas[j].getEdad() > personas[j + 1].getEdad()) {
                    Persona temp = personas[j];
                    personas[j] = personas[j + 1];
                    personas[j + 1] = temp;
                }

            }
        }
    }

    public static void mergeSort(Persona[] array, String option) {
        int n = array.length;
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        Persona[] left = Arrays.copyOfRange(array, 0, mid);
        Persona[] right = Arrays.copyOfRange(array, mid, n);
        mergeSort(left, option);
        mergeSort(right, option);
        merge(left, right, array, option);
    }

    private static void merge(Persona[] left, Persona[] right, Persona[] array, String option) {
        int i = 0;
        int j = 0;
        int k = 0;
        int leftSize = left.length;
        int rightSize = right.length;
        while (i < leftSize && j < rightSize) {
            if ("cedula".equals(option)) {
                if (left[i].getCedula() <= right[j].getCedula()) {
                    array[k++] = left[i++];
                } else {
                    array[k++] = right[j++];
                }
            } else if ("edad".equals(option)) {
                if (left[i].getEdad() <= right[j].getEdad()) {
                    array[k++] = left[i++];
                } else {
                    array[k++] = right[j++];
                }
            }
        }
        while (i < leftSize) {
            array[k++] = left[i++];
        }
        while (j < rightSize) {
            array[k++] = right[j++];
        }
    }

}
