package project.order_process;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class Thirdone {

    public static void main() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Cantidad de n\u00fameros a calcular");
        int size = sc.nextInt();
        double[] numeros = new double[size];

        Random random = new Random();
        for (int i = 0; i < size; ++i) {
            numeros[i] = random.nextDouble();
        }

        double suma = 0.0;
        for (double i : numeros) {
            suma += i;
        }
        double media = (double) suma / size;

        double varianza = 0;
        for (int i = 0; i < size; ++i) {
            double sumatoria = Math.pow(numeros[i] - media, 2.0);
            varianza += sumatoria;
        }
        double desviacion = Math.sqrt(varianza /= (double) (size - 1));
        double redondeo = Math.rint(desviacion * 100.0) / 100.0;

        HashMap<Double, Integer> frecuencia = new HashMap<>();
        for (double num : numeros) {
            if (!frecuencia.containsKey(num)) {
                frecuencia.put(num, 1);
            } else {
                frecuencia.put(num, frecuencia.get(num) + 1);
            }
        }

        int maxFrecuencia = 0;
        double moda = 0;
        for (Map.Entry<Double, Integer> entry : frecuencia.entrySet()) {
            if (entry.getValue() > maxFrecuencia) {
                maxFrecuencia = entry.getValue();
                moda = entry.getKey();
            }
        }

        Arrays.sort(numeros);
        double mediana;
        if (size % 2 == 0) {
            mediana = (numeros[size / 2] + numeros[size / 2 - 1]) / 2.0;
        } else {
            mediana = numeros[size / 2];
        }

        System.out.println("Datos : " + Arrays.toString(numeros));
        System.out.println("La media es: " + media);
        System.out.println("La mediana es: " + mediana);
        System.out.println("La moda es: " + moda);
        System.out.println("La varianza: " + varianza);
        System.out.println("La desviacion estandar es: " + redondeo);
    }
}
