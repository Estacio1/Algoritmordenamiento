package project.order_process;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Thirdthree {

    public static void main() {
        Scanner lector = new Scanner(System.in);
        String label = "Seleccione una opción:\n 1.burbuja\n 2.inserción\n 3.selección\n 4.selección\n 5. Todos";
        System.out.println(label);
        int option = lector.nextInt();

        int[] sizes = {100, 500, 1000, 5000, 10000};
        String format = "| %-10s | %-10s | %-10s |\n";
        System.out.printf(format, "Datos", "Método", "Tiempo");
        System.out.printf("|-----------|-----------|-----------|\n");
        for (int size : sizes) {
            double[] array = generateRandomArray(size);
            if (option == 5 || option == 1) {
                System.out.printf(format, size, "burbuja", measureTime(array, Thirdthree::bubbleSort));
            }
            if (option == 5 || option == 2) {
                System.out.printf(format, size, "inserción", measureTime(array, Thirdthree::insertionSort));
            }
            if (option == 5 || option == 3) {
                System.out.printf(format, size, "selección", measureTime(array, Thirdthree::selectionSort));
            }
            if (option == 5 || option == 4) {
                System.out.printf(format, size, "mergesort", measureTime(array, Thirdthree::mergeSort));
            }
            System.out.printf("|-----------|-----------|-----------|\n");
        }
    }

    private static double[] generateRandomArray(int size) {
        double[] array = new double[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            array[i] = random.nextDouble();
        }
        return array;
    }

    private static long measureTime(double[] array, SortingMethod method) {
        double[] copy = Arrays.copyOf(array, array.length);
        long startTime = System.nanoTime();
        method.sort(copy);
        long endTime = System.nanoTime();
        return endTime - startTime;
    }

    private interface SortingMethod {

        void sort(double[] array);
    }

    private static void bubbleSort(double[] array) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    double temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    private static void insertionSort(double[] array) {
        int n = array.length;
        for (int i = 1; i < n; ++i) {
            double key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j = j - 1;
            }
            array[j + 1] = key;
        }
    }

    private static void selectionSort(double[] array) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }
            double temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }

    private static void mergeSort(double[] array) {
        int n = array.length;
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        double[] left = Arrays.copyOfRange(array, 0, mid);
        double[] right = Arrays.copyOfRange(array, mid, n);
        mergeSort(left);
        mergeSort(right);
        merge(left, right, array);
    }

    private static void merge(double[] left, double[] right, double[] array) {
        int i = 0;
        int j = 0;
        int k = 0;
        int leftSize = left.length;
        int rightSize = right.length;
        while (i < leftSize && j < rightSize) {
            if (left[i] <= right[j]) {
                array[k++] = left[i++];
            } else {
                array[k++] = right[j++];
            }
        }
        while (i < leftSize) {
            array[k++] = left[i++];
        }
        while (j < rightSize) {
            array[k++] = right[j++];
        }
    }

}
