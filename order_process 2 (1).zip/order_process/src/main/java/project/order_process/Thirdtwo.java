package project.order_process;

import java.util.Scanner;

public class Thirdtwo {

    public static void main() {
        Scanner lector = new Scanner(System.in);
        String texto;
        char letraMasRepetida = 0;
        int mayorRepeticion = 0;
        System.out.println("Escribe una frase: ");
        texto = lector.nextLine();
        char[] letras = texto.toCharArray();
        for (int i = 0; i < letras.length; ++i) {
            char letraActual = letras[i];
            int contador = 0;
            for (int j = 0; j < letras.length; ++j) {
                if (letras[j] != letraActual) {
                    continue;
                }
                ++contador;
            }
            if (!(mayorRepeticion < (double) contador)) {
                continue;
            }
            mayorRepeticion = contador;
            letraMasRepetida = letraActual;
        }

        for (int i = 0; i < letras.length; ++i) {
            char letra = Character.toLowerCase(letras[i]);
            if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u') {
                letras[i] = letraMasRepetida;
            }
        }
        
        String palabra = String.valueOf(letras);
        String palabraRevertida = "";
        for (int i = palabra.length() - 1; i >= 0; i--) {
            palabraRevertida += palabra.charAt(i);
        }

        System.out.println("letraMasRepetida: " + letraMasRepetida);
        System.out.println(":Se Repite" + mayorRepeticion);
        System.out.println("Remplazo: " + palabra);
        System.out.println("Reverso: "+ palabraRevertida);
    }

}
